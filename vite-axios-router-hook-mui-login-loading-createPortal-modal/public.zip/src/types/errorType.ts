export default interface ErrorType {
  code: string;
  message: string;
}
