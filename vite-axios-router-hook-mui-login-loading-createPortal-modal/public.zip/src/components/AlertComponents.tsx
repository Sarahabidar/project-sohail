import { Alert } from "@mui/material";

const AlertComponents = () => {
  return <Alert>Hi, I'm Sarah...</Alert>;
};

export default AlertComponents;
