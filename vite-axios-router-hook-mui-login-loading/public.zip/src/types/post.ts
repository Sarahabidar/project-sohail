export default interface Post {
  id: number;
  title: string;
}
