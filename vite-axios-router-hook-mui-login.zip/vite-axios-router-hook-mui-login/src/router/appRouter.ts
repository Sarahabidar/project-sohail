export const appRouter = {
  HOME_PAGE: "/home",
  POST_LIST_PAGE: "/postlist",
  POST_ITEM_PAGE: "/postitem/",
  LOGIN_PAGE: "/loginpage",
};
