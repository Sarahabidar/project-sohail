export default interface LoginType {
  username: string;
  password: string;
}
